# AFIF161105
ini script nya
$pkg update && upgrade
$pkg install git
$pkg install python
$pkg install python2
$pkg install pip
$pkg install lolcat
git clone https://github.com/Udinarmy/AFIF161105
$ls
cd AFIF161105
python2 AFIF161105.py
GUNKAN DENGAN BIJAK
